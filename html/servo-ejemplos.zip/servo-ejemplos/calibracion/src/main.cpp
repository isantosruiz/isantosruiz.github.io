#include <Arduino.h>
#include <ESP32Servo.h>

constexpr uint8_t PIN_SERVO = 18;
constexpr int PULSO_MIN_US = 1200;
constexpr int PULSO_MAX_US = 1800;
constexpr int PULSO_INICIAL_US = 1500;
constexpr int PASO_US = 10;

Servo servo;
int pulsoUs = PULSO_INICIAL_US;

void enviarPulso(int solicitadoUs) {
    pulsoUs = constrain(solicitadoUs, PULSO_MIN_US, PULSO_MAX_US);
    servo.writeMicroseconds(pulsoUs);
    Serial.print("Pulso solicitado (us): ");
    Serial.println(pulsoUs);
}

void setup() {
    Serial.begin(115200);
    servo.setPeriodHertz(50);
    servo.setTimerWidth(16);
    servo.attach(PIN_SERVO, 1000, 2000);
    enviarPulso(PULSO_INICIAL_US);
    Serial.println("+ aumenta, - disminuye, c vuelve a 1500 us.");
}

void loop() {
    if (Serial.available() == 0) {
        return;
    }
    const char orden = static_cast<char>(Serial.read());
    switch (orden) {
        case '+':
            enviarPulso(pulsoUs + PASO_US);
            break;
        case '-':
            enviarPulso(pulsoUs - PASO_US);
            break;
        case 'c':
        case 'C':
            enviarPulso(PULSO_INICIAL_US);
            break;
        default:
            break;  // Ignora también los finales de línea.
    }
}
