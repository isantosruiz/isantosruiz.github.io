#include <Arduino.h>
#include <ESP32Servo.h>
#include <math.h>

constexpr uint8_t PIN_SERVO = 18;
constexpr uint8_t PIN_POT = 34;  // ADC1, entrada únicamente.
constexpr float ADC_MAX = 4095.0f;
constexpr uint32_t PERIODO_MS = 20;
constexpr float ALFA = 0.15f;
constexpr float VELOCIDAD_GRADOS_S = 45.0f;
constexpr float BANDA_GRADOS = 0.5f;

// Valores ilustrativos: sustituir por la calibración del montaje.
constexpr float ANGULO_MIN = 20.0f;
constexpr float ANGULO_MAX = 100.0f;
constexpr int PULSO_MIN_US = 1100;
constexpr int PULSO_MAX_US = 1900;

Servo servo;
float lecturaFiltrada = 0.0f;
float consigna = 60.0f;
uint32_t ultimoControl = 0;
uint32_t ultimoReporte = 0;
int ultimoPulso = -1;

int anguloAPulso(float grados) {
    const float limitado = constrain(grados, ANGULO_MIN, ANGULO_MAX);
    const float fraccion = (limitado - ANGULO_MIN) /
                           (ANGULO_MAX - ANGULO_MIN);
    return static_cast<int>(lroundf(
        PULSO_MIN_US + fraccion * (PULSO_MAX_US - PULSO_MIN_US)));
}

void setup() {
    Serial.begin(115200);
    analogReadResolution(12);
    analogSetPinAttenuation(PIN_POT, ADC_11db);
    servo.setPeriodHertz(50);
    servo.setTimerWidth(16);
    servo.attach(PIN_SERVO, 1000, 2000);
    ultimoPulso = anguloAPulso(consigna);
    servo.writeMicroseconds(ultimoPulso);
    lecturaFiltrada = static_cast<float>(analogRead(PIN_POT));
    ultimoControl = millis();
    ultimoReporte = ultimoControl;
}

void loop() {
    const uint32_t ahora = millis();
    if (static_cast<uint32_t>(ahora - ultimoControl) < PERIODO_MS) {
        return;
    }
    ultimoControl = ahora;

    const float lectura = static_cast<float>(analogRead(PIN_POT));
    lecturaFiltrada += ALFA * (lectura - lecturaFiltrada);
    const float objetivo = ANGULO_MIN +
        (ANGULO_MAX - ANGULO_MIN) * lecturaFiltrada / ADC_MAX;

    const float error = objetivo - consigna;
    const float pasoMax = VELOCIDAD_GRADOS_S * PERIODO_MS / 1000.0f;
    if (fabsf(error) > BANDA_GRADOS) {
        consigna += constrain(error, -pasoMax, pasoMax);
    }

    const int pulsoUs = anguloAPulso(consigna);
    if (pulsoUs != ultimoPulso) {
        servo.writeMicroseconds(pulsoUs);
        ultimoPulso = pulsoUs;
    }

    if (static_cast<uint32_t>(ahora - ultimoReporte) >= 200U) {
        ultimoReporte = ahora;
        Serial.print("Objetivo: ");
        Serial.print(objetivo, 1);
        Serial.print(" deg; consigna: ");
        Serial.print(consigna, 1);
        Serial.print(" deg; pulso: ");
        Serial.println(pulsoUs);
    }
}
