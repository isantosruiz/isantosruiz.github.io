#include <Arduino.h>
#include <ESP32Servo.h>
#include <math.h>

constexpr uint8_t PIN_SERVO = 18;
constexpr uint8_t PIN_BOTON = 27;
constexpr uint32_t PERIODO_MS = 20;
constexpr uint32_t MOVIMIENTO_MS = 1500;
constexpr uint32_t PAUSA_MS = 3000;
constexpr uint32_t ANTIRREBOTE_MS = 30;

// Valores ilustrativos: sustituir por la calibración del montaje.
constexpr float ANGULO_MIN = 20.0f;
constexpr float ANGULO_MAX = 100.0f;
constexpr int PULSO_MIN_US = 1100;
constexpr int PULSO_MAX_US = 1900;
constexpr float CERRADA = 20.0f;
constexpr float ABIERTA = 100.0f;

enum class Estado { INICIO, LISTA, APERTURA, PAUSA, CIERRE };
Estado estado = Estado::INICIO;
Servo servo;
uint32_t inicioEstado = 0;
uint32_t ultimoControl = 0;
uint32_t ultimoCambio = 0;
bool lecturaAnterior = HIGH;
bool nivelEstable = HIGH;
int ultimoPulso = -1;

int anguloAPulso(float grados) {
    const float limitado = constrain(grados, ANGULO_MIN, ANGULO_MAX);
    const float fraccion = (limitado - ANGULO_MIN) /
                           (ANGULO_MAX - ANGULO_MIN);
    return static_cast<int>(lroundf(
        PULSO_MIN_US + fraccion * (PULSO_MAX_US - PULSO_MIN_US)));
}

bool nuevaPulsacion(uint32_t ahora) {
    const bool lectura = digitalRead(PIN_BOTON);
    if (lectura != lecturaAnterior) {
        lecturaAnterior = lectura;
        ultimoCambio = ahora;
    }
    if (static_cast<uint32_t>(ahora - ultimoCambio) >= ANTIRREBOTE_MS &&
        lectura != nivelEstable) {
        nivelEstable = lectura;
        return nivelEstable == LOW;
    }
    return false;
}

float interpolar(float inicial, float final, uint32_t transcurrido) {
    const float u = constrain(
        static_cast<float>(transcurrido) / MOVIMIENTO_MS, 0.0f, 1.0f);
    const float s = u * u * (3.0f - 2.0f * u);
    return inicial + (final - inicial) * s;
}

void cambiarEstado(Estado siguiente, uint32_t ahora) {
    estado = siguiente;
    inicioEstado = ahora;
    switch (estado) {
        case Estado::LISTA:    Serial.println("Lista para un nuevo ciclo."); break;
        case Estado::APERTURA: Serial.println("Consigna de apertura."); break;
        case Estado::PAUSA:    Serial.println("Pausa programada."); break;
        case Estado::CIERRE:   Serial.println("Consigna de cierre."); break;
        default: break;
    }
}

void setup() {
    Serial.begin(115200);
    pinMode(PIN_BOTON, INPUT_PULLUP);
    servo.setPeriodHertz(50);
    servo.setTimerWidth(16);
    servo.attach(PIN_SERVO, 1000, 2000);
    ultimoPulso = anguloAPulso(CERRADA);
    servo.writeMicroseconds(ultimoPulso);
    inicioEstado = millis();
    ultimoControl = inicioEstado;
}

void loop() {
    const uint32_t ahora = millis();
    const bool pulsado = nuevaPulsacion(ahora);
    const uint32_t transcurrido = ahora - inicioEstado;

    switch (estado) {
        case Estado::INICIO:
            if (transcurrido >= 1000U) {
                cambiarEstado(Estado::LISTA, ahora);
            }
            break;
        case Estado::LISTA:
            if (pulsado) {
                cambiarEstado(Estado::APERTURA, ahora);
            }
            break;
        case Estado::APERTURA:
            if (transcurrido >= MOVIMIENTO_MS) {
                cambiarEstado(Estado::PAUSA, ahora);
            }
            break;
        case Estado::PAUSA:
            if (transcurrido >= PAUSA_MS) {
                cambiarEstado(Estado::CIERRE, ahora);
            }
            break;
        case Estado::CIERRE:
            if (transcurrido >= MOVIMIENTO_MS) {
                cambiarEstado(Estado::LISTA, ahora);
            }
            break;
    }

    if (static_cast<uint32_t>(ahora - ultimoControl) < PERIODO_MS) {
        return;
    }
    ultimoControl = ahora;
    const uint32_t tiempoMovimiento = ahora - inicioEstado;
    float consigna = CERRADA;
    if (estado == Estado::APERTURA) {
        consigna = interpolar(CERRADA, ABIERTA, tiempoMovimiento);
    } else if (estado == Estado::PAUSA) {
        consigna = ABIERTA;
    } else if (estado == Estado::CIERRE) {
        consigna = interpolar(ABIERTA, CERRADA, tiempoMovimiento);
    }

    const int pulsoUs = anguloAPulso(consigna);
    if (pulsoUs != ultimoPulso) {
        servo.writeMicroseconds(pulsoUs);
        ultimoPulso = pulsoUs;
    }
}
