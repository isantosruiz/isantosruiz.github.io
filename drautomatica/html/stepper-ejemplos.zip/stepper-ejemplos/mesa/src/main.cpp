#include <Arduino.h>
#include <AccelStepper.h>
#include <math.h>
#include "PasoDir.h"

constexpr uint8_t PIN_HOME = 32;
constexpr uint8_t PIN_LIMITE = 33;
constexpr float AVANCE_MM_VUELTA = 8.0f;
constexpr float PULSOS_MM = PULSOS_VUELTA / AVANCE_MM_VUELTA;
constexpr float RECORRIDO_UTIL_MM = 40.0f;
constexpr uint32_t FILTRO_MS = 10;

// Cada contacto NC une su GPIO a GND. Una resistencia externa de 10 kΩ
// conecta ese GPIO a 3V3. HIGH significa contacto abierto.
struct EntradaNC {
    uint8_t pin;
    explicit EntradaNC(uint8_t numero) : pin(numero) {}
    bool anterior = LOW;
    bool abierta = LOW;
    uint32_t cambio = 0;
    void begin() {
        pinMode(pin, INPUT);
        anterior = abierta = digitalRead(pin);
        cambio = millis();
    }
    void actualizar(uint32_t ahora) {
        const bool lectura = digitalRead(pin);
        if (lectura != anterior) {
            anterior = lectura;
            cambio = ahora;
        }
        if (ahora - cambio >= FILTRO_MS) abierta = lectura;
    }
};

EntradaNC home{PIN_HOME};
EntradaNC limite{PIN_LIMITE};
AccelStepper eje(pasoPositivo, pasoNegativo);
enum class Estado {
    ESPERA, LIBERAR, BUSCAR, RETROCEDER, APROXIMAR, RETIRAR,
    LISTO, MOVER, ERROR
};
Estado estado = Estado::ESPERA;
uint32_t inicioFase = 0;

long pulsos(float mm) { return lroundf(mm * PULSOS_MM); }

void fallar(const char* mensaje) {
    // Detiene la emisión de pulsos; no desenergiza el motor.
    eje.setCurrentPosition(eje.currentPosition());
    estado = Estado::ERROR;
    Serial.println(mensaje);
}

void faseConstante(Estado siguiente, float velocidad) {
    eje.setCurrentPosition(0);
    eje.setSpeed(velocidad);
    inicioFase = millis();
    estado = siguiente;
}

bool excede(float recorridoMm, uint32_t tiempoMs, uint32_t ahora) {
    return labs(eje.currentPosition()) >= pulsos(recorridoMm) ||
           ahora - inicioFase >= tiempoMs;
}

void moverA(float mm) {
    if (mm < 0.0f || mm > RECORRIDO_UTIL_MM) return;
    eje.moveTo(pulsos(mm));
    estado = Estado::MOVER;
}

void setup() {
    Serial.begin(115200);
    prepararInterfaz();
    home.begin();
    limite.begin();
    eje.setMaxSpeed(10.0f * PULSOS_MM);
    eje.setAcceleration(20.0f * PULSOS_MM);
    Serial.println("h: buscar origen; después, a: ir a 20 mm; r: volver a 0 mm.");
}

void loop() {
    const uint32_t ahora = millis();
    home.actualizar(ahora);
    limite.actualizar(ahora);
    if (estado == Estado::ERROR) return; // Corregir la causa y reiniciar.
    if (limite.abierta) {
        fallar("Parada: límite positivo abierto.");
        return;
    }

    char orden = 0;
    if (Serial.available() > 0) orden = static_cast<char>(Serial.read());
    if (estado == Estado::ESPERA && orden == 'h') {
        if (home.abierta) faseConstante(Estado::LIBERAR, 2.0f * PULSOS_MM);
        else faseConstante(Estado::BUSCAR, -2.0f * PULSOS_MM);
        return;
    }
    if ((estado == Estado::LISTO || estado == Estado::MOVER) && home.abierta) {
        fallar("Parada: HOME abierto fuera de la referencia.");
        return;
    }

    switch (estado) {
        case Estado::LIBERAR:
            if (!home.abierta) {
                faseConstante(Estado::BUSCAR, -2.0f * PULSOS_MM);
            } else if (excede(5.0f, 10000, ahora)) {
                fallar("No se pudo liberar HOME.");
            } else eje.runSpeed();
            break;
        case Estado::BUSCAR:
            if (home.abierta) {
                faseConstante(Estado::RETROCEDER, 2.0f * PULSOS_MM);
            } else if (excede(60.0f, 45000, ahora)) {
                fallar("HOME no encontrado.");
            } else eje.runSpeed();
            break;
        case Estado::RETROCEDER:
            if (eje.currentPosition() >= pulsos(3.0f) && !home.abierta) {
                faseConstante(Estado::APROXIMAR, -0.5f * PULSOS_MM);
            } else if (excede(5.0f, 10000, ahora)) {
                fallar("HOME no cerró al retroceder.");
            } else eje.runSpeed();
            break;
        case Estado::APROXIMAR:
            if (home.abierta) {
                eje.setCurrentPosition(0);
                eje.moveTo(pulsos(5.0f));
                inicioFase = ahora;
                estado = Estado::RETIRAR;
            } else if (excede(6.0f, 20000, ahora)) {
                fallar("Falló la aproximación lenta.");
            } else eje.runSpeed();
            break;
        case Estado::RETIRAR:
            eje.run();
            if (eje.distanceToGo() == 0) {
                if (home.abierta) fallar("HOME permanece abierto.");
                else {
                    eje.setCurrentPosition(0); // Origen útil, 5 mm tras la captura.
                    estado = Estado::LISTO;
                    Serial.println("Origen establecido. a: 20 mm; r: 0 mm.");
                }
            } else if (ahora - inicioFase > 10000) fallar("Retirada incompleta.");
            break;
        case Estado::LISTO:
            if (orden == 'a') moverA(20.0f);
            if (orden == 'r') moverA(0.0f);
            break;
        case Estado::MOVER:
            eje.run();
            if (eje.distanceToGo() == 0) {
                estado = Estado::LISTO;
                Serial.print("Posición calculada (mm): ");
                Serial.println(eje.currentPosition() / PULSOS_MM, 3);
            }
            break;
        default:
            break;
    }
}
