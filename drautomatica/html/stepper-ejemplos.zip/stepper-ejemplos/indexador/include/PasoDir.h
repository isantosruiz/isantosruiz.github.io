#pragma once
#include <Arduino.h>

constexpr uint8_t PIN_PUL = 18;
constexpr uint8_t PIN_DIR = 19;
constexpr long PASOS_ENTEROS = 200;
constexpr long MICROPASOS = 8;  // Debe coincidir con los interruptores del driver.
constexpr long PULSOS_VUELTA = PASOS_ENTEROS * MICROPASOS;
constexpr uint32_t T_DIR_US = 20;
constexpr uint32_t T_PUL_US = 20;
constexpr uint32_t T_HOLD_US = 20;

inline void prepararInterfaz() {
    digitalWrite(PIN_PUL, LOW);
    digitalWrite(PIN_DIR, LOW);
    pinMode(PIN_PUL, OUTPUT);
    pinMode(PIN_DIR, OUTPUT);
}

inline void emitirPaso(bool positivo) {
    digitalWrite(PIN_DIR, positivo ? HIGH : LOW);
    delayMicroseconds(T_DIR_US);
    digitalWrite(PIN_PUL, HIGH);
    delayMicroseconds(T_PUL_US);
    digitalWrite(PIN_PUL, LOW);
    delayMicroseconds(T_HOLD_US);
}

inline void pasoPositivo() { emitirPaso(true); }
inline void pasoNegativo() { emitirPaso(false); }
