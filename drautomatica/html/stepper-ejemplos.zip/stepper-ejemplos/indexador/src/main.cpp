#include <Arduino.h>
#include <AccelStepper.h>
#include "PasoDir.h"

constexpr uint8_t PIN_BOTON = 27;
constexpr uint32_t REBOTE_MS = 30;
constexpr long CUARTO_VUELTA = PULSOS_VUELTA / 4;
static_assert(PULSOS_VUELTA % 4 == 0, "El índice debe ser un número entero.");

AccelStepper eje(pasoPositivo, pasoNegativo);
bool lecturaAnterior = HIGH;
bool nivelEstable = HIGH;
bool enMovimiento = false;
uint32_t ultimoCambio = 0;

bool nuevaPulsacion() {
    const uint32_t ahora = millis();
    const bool lectura = digitalRead(PIN_BOTON);
    if (lectura != lecturaAnterior) {
        lecturaAnterior = lectura;
        ultimoCambio = ahora;
    }
    if (ahora - ultimoCambio >= REBOTE_MS && lectura != nivelEstable) {
        nivelEstable = lectura;
        return nivelEstable == LOW;
    }
    return false;
}

void setup() {
    Serial.begin(115200);
    prepararInterfaz();
    pinMode(PIN_BOTON, INPUT_PULLUP);
    eje.setMaxSpeed(800.0f);      // Pulsos/s.
    eje.setAcceleration(800.0f); // Pulsos/s².
    eje.setCurrentPosition(0);   // Referencia relativa, sin medición.
    Serial.println("Una pulsación solicita un avance de 90 grados.");
}

void loop() {
    const bool pulsado = nuevaPulsacion();
    if (pulsado && !enMovimiento) {
        eje.move(CUARTO_VUELTA);
        enMovimiento = true;
    }
    eje.run();
    if (enMovimiento && eje.distanceToGo() == 0) {
        enMovimiento = false;
        eje.setCurrentPosition(0);  // La próxima orden vuelve a ser relativa.
        Serial.println("Índice completado según el contador de pulsos.");
    }
}
