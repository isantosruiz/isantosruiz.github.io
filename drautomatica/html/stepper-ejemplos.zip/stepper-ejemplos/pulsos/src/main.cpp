#include <Arduino.h>
#include "PasoDir.h"

constexpr uint32_t PERIODO_US = 5000;  // Aproximadamente 200 pulsos/s.
static_assert(PERIODO_US > T_DIR_US + T_PUL_US + T_HOLD_US,
              "El periodo debe superar el tiempo de la secuencia.");

void unaVuelta(bool positivo) {
    for (long k = 0; k < PULSOS_VUELTA; ++k) {
        emitirPaso(positivo);
        delayMicroseconds(PERIODO_US - T_DIR_US - T_PUL_US - T_HOLD_US);
        if ((k + 1) % 32 == 0) delay(1); // Cede tiempo a las tareas del ESP32.
    }
}

void setup() {
    Serial.begin(115200);
    prepararInterfaz();
    Serial.println("Motor sin carga. f: una vuelta; r: una vuelta inversa.");
}

void loop() {
    if (Serial.available() == 0) return;
    const char orden = static_cast<char>(Serial.read());
    if (orden != 'f' && orden != 'r') return;
    unaVuelta(orden == 'f');
    Serial.println("Secuencia de pulsos terminada.");
}
