#include <Arduino.h>
#include "PwmCD.h"
#include "MandoCD.h"

constexpr uint8_t PIN_INA = 26;
constexpr uint8_t PIN_INB = 27;
constexpr uint8_t PIN_ENA = 32;
constexpr uint8_t PIN_ENB = 33;
MandoCD mando(-1000);
RampaCD rampa;
bool habilitado = false;
bool fallo = false;
uint32_t inicioHabilitacionUs = 0;

void libre() {
    // OPEN_DRAIN: LOW deshabilita; HIGH libera la línea hacia el pull-up.
    digitalWrite(PIN_ENA, LOW);
    digitalWrite(PIN_ENB, LOW);
    escribirPWM(0);
    digitalWrite(PIN_INA, LOW);
    digitalWrite(PIN_INB, LOW);
    habilitado = false;
}
void aplicar(int valor) {
    if (valor == 0) { libre(); return; }
    digitalWrite(PIN_INA, valor > 0 ? HIGH : LOW);
    digitalWrite(PIN_INB, valor > 0 ? LOW : HIGH);
    if (!habilitado) {
        digitalWrite(PIN_ENA, HIGH);
        digitalWrite(PIN_ENB, HIGH);
        inicioHabilitacionUs = micros();
        habilitado = true;
    }
    escribirPWM(valor);
}
void setup() {
    digitalWrite(PIN_ENA, LOW);
    digitalWrite(PIN_ENB, LOW);
    pinMode(PIN_ENA, OUTPUT_OPEN_DRAIN);
    pinMode(PIN_ENB, OUTPUT_OPEN_DRAIN);
    digitalWrite(PIN_INA, LOW);
    digitalWrite(PIN_INB, LOW);
    pinMode(PIN_INA, OUTPUT);
    pinMode(PIN_INB, OUTPUT);
    prepararPWM();
    libre();
    Serial.begin(115200);
    Serial.println("VNH5019: enviar -1000..1000 o x, seguido de Enter.");
}
void loop() {
    const uint32_t ahora = millis();
    if (fallo) return; // Corregir la causa y reiniciar la placa.
    if (habilitado && micros() - inicioHabilitacionUs >= 1000 &&
        (digitalRead(PIN_ENA) == LOW || digitalRead(PIN_ENB) == LOW)) {
        fallo = true;
        rampa.parar(ahora);
        libre();
        Serial.println("Falla indicada por el driver. Salida desactivada.");
        return;
    }
    atenderMando(mando, rampa, ahora);
    aplicar(rampa.actualizar(ahora));
}
