#pragma once
#include <Arduino.h>
#include <stdlib.h>
#include <ctype.h>

// Una línea contiene un entero o la letra x. No espera datos del puerto.
class MandoCD {
public:
    enum class Evento { Ninguno, Consigna, Parar, Invalido };
    explicit MandoCD(int minimo) : minimo_(minimo) {}
    Evento leer(int& valor) {
        for (uint8_t n = 0; n < 32 && Serial.available(); ++n) {
            const char c = static_cast<char>(Serial.read());
            if (c == '\r') continue;
            if (c != '\n') {
                if (usados_ + 1 < sizeof(linea_)) linea_[usados_++] = c;
                else desborde_ = true;
                continue;
            }
            linea_[usados_] = '\0';
            const bool mala = desborde_;
            usados_ = 0;
            desborde_ = false;
            if (mala) return Evento::Invalido;
            if (linea_[0] == '\0') continue;
            if (linea_[0] == 'x' && linea_[1] == '\0') return Evento::Parar;
            const char* inicio = linea_;
            if (*inicio == '+' || *inicio == '-') ++inicio;
            if (!isdigit(static_cast<unsigned char>(*inicio))) return Evento::Invalido;
            for (const char* p = inicio; *p; ++p)
                if (!isdigit(static_cast<unsigned char>(*p))) return Evento::Invalido;
            char* fin = nullptr;
            const long numero = strtol(linea_, &fin, 10);
            if (*fin || numero < minimo_ || numero > 1000) return Evento::Invalido;
            valor = static_cast<int>(numero);
            return Evento::Consigna;
        }
        return Evento::Ninguno;
    }
private:
    int minimo_;
    char linea_[16] = {};
    uint8_t usados_ = 0;
    bool desborde_ = false;
};

class RampaCD {
public:
    void solicitar(int valor) { objetivo_ = constrain(valor, -1000, 1000); }
    void parar(uint32_t ahora) {
        if (actual_ != 0) desdeCero_ = ahora;
        actual_ = objetivo_ = 0;
        ultimo_ = ahora;
    }
    int actualizar(uint32_t ahora) {
        if (ahora - ultimo_ < 10) return actual_;
        ultimo_ = ahora;
        int meta = objetivo_;
        if (actual_ != 0 && signo(actual_) * signo(meta) < 0) meta = 0;
        if (actual_ == 0 && signo(meta) != 0 && ultimoSentido_ != 0 &&
            signo(meta) != ultimoSentido_ && ahora - desdeCero_ < PAUSA_MS)
            return 0;
        const int anterior = actual_;
        if (actual_ < meta) actual_ = min(actual_ + 10, meta);
        if (actual_ > meta) actual_ = max(actual_ - 10, meta);
        if (actual_ != 0) ultimoSentido_ = signo(actual_);
        else if (anterior != 0) desdeCero_ = ahora;
        return actual_;
    }
private:
    static int signo(int x) { return (x > 0) - (x < 0); }
    static constexpr uint32_t PAUSA_MS = 500;
    int actual_ = 0, objetivo_ = 0, ultimoSentido_ = 0;
    uint32_t ultimo_ = 0, desdeCero_ = 0;
};

inline void atenderMando(MandoCD& mando, RampaCD& rampa, uint32_t ahora) {
    int pedido = 0;
    switch (mando.leer(pedido)) {
        case MandoCD::Evento::Consigna:
            rampa.solicitar(pedido);
            Serial.print("Consigna de mando: ");
            Serial.println(pedido);
            break;
        case MandoCD::Evento::Parar:
            rampa.parar(ahora);
            Serial.println("Salida desactivada.");
            break;
        case MandoCD::Evento::Invalido:
            Serial.println("Orden inválida; se conserva la consigna anterior.");
            break;
        default: break;
    }
}
