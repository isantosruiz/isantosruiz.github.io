#pragma once
#include <Arduino.h>

// API LEDC de Arduino-ESP32 2.0.17, fijada en platformio.ini.
constexpr uint8_t PIN_PWM = 25;
constexpr uint8_t CANAL_PWM = 0;
constexpr uint32_t FRECUENCIA_PWM = 20000;
constexpr uint8_t BITS_PWM = 11;
constexpr uint32_t CUENTA_MAX = (1u << BITS_PWM) - 1;

inline void prepararPWM() {
    digitalWrite(PIN_PWM, LOW);
    pinMode(PIN_PWM, OUTPUT);
    ledcSetup(CANAL_PWM, FRECUENCIA_PWM, BITS_PWM);
    ledcAttachPin(PIN_PWM, CANAL_PWM);
    ledcWrite(CANAL_PWM, 0);
}
inline void escribirPWM(int mando) {
    const uint32_t magnitud = static_cast<uint32_t>(abs(constrain(mando, -1000, 1000)));
    const uint32_t cuenta = (magnitud * CUENTA_MAX + 500u) / 1000u;
    ledcWrite(CANAL_PWM, cuenta);
}
