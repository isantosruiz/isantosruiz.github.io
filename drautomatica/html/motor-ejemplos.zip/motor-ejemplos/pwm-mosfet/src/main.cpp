#include <Arduino.h>
#include "PwmCD.h"
#include "MandoCD.h"

MandoCD mando(0); // Este montaje solo admite un sentido.
RampaCD rampa;

void setup() {
    prepararPWM();
    Serial.begin(115200);
    Serial.println("PWM unidireccional. Enviar 0..1000 o x, seguido de Enter.");
}
void loop() {
    const uint32_t ahora = millis();
    atenderMando(mando, rampa, ahora);
    escribirPWM(rampa.actualizar(ahora));
}
