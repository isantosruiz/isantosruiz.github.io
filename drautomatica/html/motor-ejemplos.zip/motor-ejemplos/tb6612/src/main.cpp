#include <Arduino.h>
#include "PwmCD.h"
#include "MandoCD.h"

constexpr uint8_t PIN_IN1 = 26;
constexpr uint8_t PIN_IN2 = 27;
constexpr uint8_t PIN_STBY = 14;
MandoCD mando(-1000);
RampaCD rampa;

void aplicar(int valor) {
    if (valor == 0) {
        digitalWrite(PIN_STBY, LOW); // Ambos puentes en alta impedancia.
        escribirPWM(0);
        digitalWrite(PIN_IN1, LOW);
        digitalWrite(PIN_IN2, LOW);
        return;
    }
    digitalWrite(PIN_IN1, valor > 0 ? HIGH : LOW);
    digitalWrite(PIN_IN2, valor > 0 ? LOW : HIGH);
    escribirPWM(valor);
    digitalWrite(PIN_STBY, HIGH);
}
void setup() {
    digitalWrite(PIN_STBY, LOW);
    pinMode(PIN_STBY, OUTPUT);
    digitalWrite(PIN_IN1, LOW);
    digitalWrite(PIN_IN2, LOW);
    pinMode(PIN_IN1, OUTPUT);
    pinMode(PIN_IN2, OUTPUT);
    prepararPWM();
    Serial.begin(115200);
    Serial.println("TB6612: enviar -1000..1000 o x, seguido de Enter.");
}
void loop() {
    const uint32_t ahora = millis();
    atenderMando(mando, rampa, ahora);
    aplicar(rampa.actualizar(ahora));
}
